package tileworld.agent;

import sim.util.Int2D;
import tileworld.Parameters;
import tileworld.environment.TWDirection;
import tileworld.environment.TWEnvironment;

import java.util.ArrayList;

public class TimourAgent extends MyAgent{
    public TimourAgent(int index, String name, int xpos, int ypos, TWEnvironment env, double fuelLevel) {
        super(index, name, xpos, ypos, env, fuelLevel);
    }



    private Int2D nextPoint(Int2D point, TWDirection dir, int amt) {
        return new Int2D(point.x + dir.dx * amt, point.y + dir.dy * amt);
    }

    @Override
    public void addGoalsForFuelStation() {
        if (this.quarter == BoardQuarter.WORKING_AGENT) {
            this.mode = Mode.COLLECT;
            this.think();
            return;
        }
        this.planner.voidGoals();
        ArrayList<Int2D> goals = this.planner.getGoals();
        goals.add(this.quarter.regionCenter());

        int quarterWidth = Parameters.xDimension / 2;
        int quarterHeight = Parameters.yDimension / 2;

        TWDirection dir = TWDirection.Z;


        for (int stepLength=1;
             stepLength < Integer.min(quarterWidth, quarterHeight)
                     / Parameters.defaultSensorRange;
             stepLength ++) {

            dir = dir.next();
            goals.add(nextPoint(goals.get(goals.size() - 1), dir, stepLength
                    * Parameters.defaultSensorRange));

            dir = dir.next();
            goals.add(nextPoint(goals.get(goals.size() - 1), dir, stepLength
                    * Parameters.defaultSensorRange));
        }
    }
}
