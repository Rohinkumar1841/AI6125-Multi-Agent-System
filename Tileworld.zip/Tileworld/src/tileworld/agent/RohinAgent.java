//package tileworld.agent;
//
//import sim.util.Int2D;
//import tileworld.Parameters;
//import tileworld.environment.TWDirection;
//import tileworld.environment.TWEnvironment;
//
//import java.util.*;
//
//public class RohinAgent extends MyAgent {
//    public RohinAgent(int index, String name, int xpos, int ypos, TWEnvironment env, double fuelLevel) {
//        super(index, name, xpos, ypos, env, fuelLevel);
//    }
//
//    private Int2D nextPoint(Int2D point, TWDirection dir, int amt) {
//        return new Int2D(point.x + dir.dx * amt, point.y + dir.dy * amt);
//    }
//
//    @Override
//    public void addGoalsForFuelStation() {
//        if (this.quarter == BoardQuarter.WORKING_AGENT) {
//            this.mode = Mode.COLLECT;
//            this.think();
//            return;
//        }
//
//        this.planner.voidGoals();
//        Queue<Int2D> goals = new LinkedList<>();
//        // Start from the corner instead of the center
//        goals.add(new Int2D(0, 0));
//
//        int quarterWidth = Parameters.xDimension / 2;
//        int quarterHeight = Parameters.yDimension / 2;
//
//        TWDirection[] directions = TWDirection.values();
//        Set<Int2D> visited = new HashSet<>();
//
//        while (!goals.isEmpty()) {
//            Int2D current = goals.poll();
//            for (TWDirection dir : directions) {
//                Int2D next = nextPoint(current, dir, Parameters.defaultSensorRange);
//                if (isValidPoint(next, quarterWidth, quarterHeight, visited)) {
//                    goals.add(next);
//                    visited.add(next);
//                }
//            }
//        }
//    }
//
//    private boolean isValidPoint(Int2D point, int maxWidth, int maxHeight, Set<Int2D> visited) {
//        return point.x >= 0 && point.x < maxWidth && point.y >= 0 && point.y < maxHeight && !visited.contains(point);
//    }
//}

package tileworld.agent;

import sim.util.Int2D;
import tileworld.environment.TWEnvironment;
import tileworld.Parameters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.concurrent.atomic.AtomicReference;

public class RohinAgent extends MyAgent {
    public RohinAgent(int index, String name, int xpos, int ypos, TWEnvironment env, double fuelLevel) {
        super(index, name, xpos, ypos, env, fuelLevel);
    }

    @Override
    public void addGoalsForFuelStation() {
        if (this.quarter == BoardQuarter.WORKING_AGENT) {
            this.mode = Mode.COLLECT;
            this.think();
            return;
        }
        this.planner.voidGoals();

        ArrayList<Int2D> goals = this.planner.getGoals();

        ArrayList<Int2D> checkpoints = getFuelStationSearchCheckpoints(this.quarter);
        ArrayList<Int2D> sortedCheckpoints = sortCheckpoints(checkpoints, new Int2D(this.getX(), this.getY()));

        for (Int2D checkpoint : sortedCheckpoints) {
            goals.add(checkpoint);
        }
    }

    private ArrayList<Int2D> getFuelStationSearchCheckpoints(BoardQuarter quarter) {
        // Get checkpoint steps
        int midX = Parameters.xDimension / 2;
        int midY = Parameters.yDimension / 2;

        int xIncrements = Parameters.defaultSensorRange;
        int yIncrements = Parameters.defaultSensorRange;

        // Get checkpoint locations
        ArrayList<Int2D> checkpoints = new ArrayList<>();
        switch (quarter) {
            case NW:
                for (int x = 0 + xIncrements; x < midX; x = x + xIncrements) {
                    for (int y = 0 + yIncrements; y < midY; y = y + yIncrements) {
                        checkpoints.add(new Int2D(x, y));
                    }
                }
                return checkpoints;
            case NE:
                for (int x = midX + xIncrements; x < Parameters.xDimension; x = x + xIncrements) {
                    for (int y = 0 + yIncrements; y < midY; y = y + yIncrements) {
                        checkpoints.add(new Int2D(x, y));
                    }
                }
                return checkpoints;
            case SW:
                for (int x = 0 + xIncrements; x < midX; x = x + xIncrements) {
                    for (int y = midY + yIncrements; y < Parameters.yDimension; y = y + yIncrements) {
                        checkpoints.add(new Int2D(x, y));
                    }
                }
                return checkpoints;
            case SE:
                for (int x = midX + xIncrements; x < Parameters.xDimension; x = x + xIncrements) {
                    for (int y = midY + yIncrements; y < Parameters.yDimension; y = y + yIncrements) {
                        checkpoints.add(new Int2D(x, y));
                    }
                }
                return checkpoints;
        }
        throw new IllegalStateException();
    }

    private ArrayList<Int2D> sortCheckpoints(ArrayList<Int2D> checkpoints, Int2D agentPos) {
        ArrayList<Int2D> sortedCheckpoints = new ArrayList<>();

        AtomicReference<Int2D> anchorPoint = new AtomicReference<>(agentPos);
        while (!checkpoints.isEmpty()) {
            Int2D closestCheckpoint = checkpoints
                .stream()
                .min(Comparator.comparingDouble(o -> o.distance(anchorPoint.get())))
                .orElseThrow(null);
            sortedCheckpoints.add(closestCheckpoint);
            checkpoints.remove(closestCheckpoint);

            anchorPoint.set(closestCheckpoint);
        }

        return sortedCheckpoints;
    }
}
