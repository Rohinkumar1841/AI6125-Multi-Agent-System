package tileworld.agent;

import java.util.*;
import java.util.stream.Stream;

import tileworld.environment.TWObject;
import tileworld.environment.TWTile;
import tileworld.Parameters;
import tileworld.environment.TWDirection;
import tileworld.environment.TWEntity;
import tileworld.environment.TWEnvironment;
import tileworld.environment.TWFuelStation;
import tileworld.environment.TWHole;
import tileworld.exceptions.CellBlockedException;
import tileworld.planners.DefaultTWPlanner;
import sim.util.Bag;
import sim.util.Int2D;
import sim.util.IntBag;

public class MyAgent extends TWAgent {
	enum Mode {
		RMOVE, FIND_FUEL_STATION, COLLECT, FILL, REFUEL, WAIT
	}

	private int index;
	private String name;
	private MyMemory memory;
	protected DefaultTWPlanner planner; // useful if we wanna do this with inheritance, not composition
	protected Mode mode;
	private double fuelThreshold;
	private static final Object TWHole = null;
	private static final Object TWTile = null;

	protected BoardQuarter quarter;

	TWObject neighborTile;
	TWObject neighborHole;

	public MyAgent(int index, String name, int xpos, int ypos, TWEnvironment env, double fuelLevel) {
        super(xpos,ypos,env,fuelLevel);
        this.index = index;
        this.name = name;
        this.fuelThreshold = this.getFuelLevel() / 5 ;
        this.planner = new DefaultTWPlanner(this);
		this.sensor = new TWAgentSensor(this, Parameters.defaultSensorRange);
        this.memory = new MyMemory(this, env.schedule, env.getxDimension(), env.getyDimension());
		OrganisedMessage msg = new OrganisedMessage(this.getName(), "Hello");
		msg.addMessage("LOCATION", new Int2D(xpos, ypos)); // TODO: shouldn't the key be AgentPosition?
		this.getEnvironment().receiveMessage(msg);
		System.out.println("msg agent position"+ msg.getAgentPosition());
	}


	public MyAgent(int xpos, int ypos, TWEnvironment env, double fuelLevel) {
		super(xpos, ypos, env, fuelLevel);
		this.planner = new DefaultTWPlanner(this);
	}

	/**
	 * Goes through locations and assigns each location to a corner -- or to work
	 * @param agents Locations of all agents *including this one*
	 */
	protected void assignCorners(ArrayList<Int2D> agents) {
		ArrayList<BoardQuarter> regions = new ArrayList<>(Arrays.asList(
				BoardQuarter.NE, BoardQuarter.NW, BoardQuarter.SE, BoardQuarter.SW
		));

		for (BoardQuarter quarter: regions) {
			Int2D chosenAgent = agents
					.stream()
					.min(Comparator.comparingDouble((Int2D o) -> o.distance(quarter.regionCenter())))
					//.orElseThrow(null);
					.orElseThrow(() -> new IllegalArgumentException("No agents found")); // Provide a Supplier for the exception			
			agents.remove(chosenAgent);

			if (chosenAgent.getX() == this.x && chosenAgent.getY() == this.y) {
				this.quarter = quarter;
				return;
			}
		}

		this.quarter = BoardQuarter.WORKING_AGENT;
	}

    public void communicate() {
    	OrganisedMessage msg = new OrganisedMessage(this.getName(), "");
    	Bag sensedObjects = new Bag();
    	IntBag objectXCoords = new IntBag();
    	IntBag objectYCoords = new IntBag();
    	this.memory.getMemoryGrid().getNeighborsMaxDistance(x, y, Parameters.defaultSensorRange, false, sensedObjects, objectXCoords, objectYCoords);

  		msg.addFuelStationPosition(this.memory.getFuelStation());
  		msg.addSensedObjects(sensedObjects, new Int2D(x, y));
  		this.getEnvironment().receiveMessage(msg);

    }

	@Override
	//begin of update
	protected TWThought think() {
		ArrayList<Message> messages = this.getEnvironment().getMessages();
		ArrayList<Int2D> locs = new ArrayList<>();
		for (Message msg : messages) {
			if (msg == null || !msg.getMessage().equals("OrganisedMessage")) {
				continue; // Not one of us.
			}
			OrganisedMessage m = (OrganisedMessage) msg;
			locs.add(m.getAgentPosition());
  			if (((OrganisedMessage) m).getMessageMap() == null
					|| Objects.equals(m.getFrom(), this.getName())) continue;

			Int2D fuelStationPos = m.getFuelStationPosition();
  			if (this.memory.getFuelStation() == null && fuelStationPos != null) {
  				this.memory.setFuelStation(fuelStationPos.x, fuelStationPos.y);
  			}
  			Bag sharedObjects = m.getSensedObjects();
  			Int2D posAgent = m.getAgentPosition();
  			if (sharedObjects != null) {
  				this.memory.mergeMemory(sharedObjects, posAgent);
  			}
  		}

		if (this.quarter == null) {
			assert locs.size() == Parameters.numAgent; // TODO: Am I missing edge cases here?
			System.out.println("size of locs: "+locs.size());
			this.assignCorners(locs);
		}

    	PriorityQueue<TWEntity> neighborTiles;
    	PriorityQueue<TWEntity> neighborHoles;

		neighborTiles = this.memory.getNearbyAllSortedObjects(x, y, 50, TWTile.class);
		neighborHoles = this.memory.getNearbyAllSortedObjects(x, y, 50, TWHole.class);


		ArrayList<TWEntity> tiles = detectObjectNoCollision(neighborTiles, this.memory.neighbouringAgents);
		ArrayList<TWEntity> holes = detectObjectNoCollision(neighborHoles, this.memory.neighbouringAgents);


		TWTile tileTarget = null;
		TWHole holeTarget = null;

		if (tiles != null) {
			tileTarget = (TWTile) tiles.get(0);
		}
		if (holes != null) {
			holeTarget = (TWHole) holes.get(0);
		}

		tileTarget = this.getMemory().getNearbyTile(x, y, 50);
		holeTarget = this.getMemory().getNearbyHole(x, y, 50);



		// Set initial mode to "RMOVE" (Random Move)
		mode = Mode.RMOVE;

		// Check if a fuel station is in memory
		if (memory.getFuelStation() == null && this.quarter != BoardQuarter.WORKING_AGENT) {
		    mode = Mode.FIND_FUEL_STATION;
		} else if (memory.getFuelStation() != null && (this.getFuelLevel() < this.fuelThreshold ||
				this.getFuelLevel() * 0.8 < this.getDistanceTo(memory.getFuelStation().x,
						memory.getFuelStation().y))) {
		    // Check if fuel level is below a certain threshold or if the agent is relatively close to the fuel station
		        mode = Mode.REFUEL;
		    } else if (mode != Mode.FIND_FUEL_STATION) {
		        // Check if the agent is not in finding fuel station mode
		            // Check other conditions
		            if (this.hasTile() && holeTarget != null) {
		                mode = Mode.FILL; // Switch to filling mode if the agent has a tile and there's a hole target
		            } else if (!this.hasTile() && tileTarget != null) {
		                mode = Mode.COLLECT; // Switch to collecting mode if the agent doesn't have a tile and there's a tile target
		            }
		        }


		// Retrieve object at current location
		Object curLocObj = this.memory.getMemoryGrid().get(x, y);

		// Check if an object exists at the current location
		if (curLocObj != null) {
		    // Action decision based on object type
		    if (curLocObj instanceof TWFuelStation && (this.fuelLevel < (0.75 * Parameters.defaultFuelLevel))) {
		        // Refuel if fuel station and fuel level is below 75%
		        return new TWThought(TWAction.REFUEL, null);
		    } else if (curLocObj instanceof TWHole && this.getEnvironment().canPutdownTile((TWHole) curLocObj, this) && this.hasTile()) {
		        // Put down tile if hole, agent can put down tile, and agent has a tile
		        return new TWThought(TWAction.PUTDOWN, null);
		    } else if (curLocObj instanceof TWTile && this.getEnvironment().canPickupTile((TWTile) curLocObj, this) && this.carriedTiles.size() < 3) {
		        // Pick up tile if tile, agent can pick up tile, and agent is not carrying maximum number of tiles
		        return new TWThought(TWAction.PICKUP, null);
		    }
		}

		//Begin of 2nd update
//Begin of 3rd update
		if (mode == Mode.FIND_FUEL_STATION) {

			if (this.planner.getGoals().isEmpty()) {
				addGoalsForFuelStation();
			}
			else {
				if (this.planner.getGoals().contains(new Int2D(this.x, this.y))) {
					int index = planner.getGoals().indexOf(new Int2D(this.x, this.y));
					if (index != -1) planner.getGoals().remove(0);
				}
			}

			for (int i = 0; i < planner.getGoals().size(); i++) {
				System.out.println("Goals " + i + ": " + planner.getGoals().get(i));
			}
		}
		else {
			planner.voidGoals();
			planner.voidPlan();
			if (mode == Mode.REFUEL) {
				planner.getGoals().add(memory.getFuelStation());
			}  else if ((mode == Mode.FILL)){
				planner.getGoals().add(new Int2D(holeTarget.getX(), holeTarget.getY()));
			} else if ((mode == Mode.COLLECT)){
				planner.getGoals().add(new Int2D(tileTarget.getX(), tileTarget.getY()));
			} else if (mode == Mode.WAIT){
				return new TWThought(TWAction.MOVE, TWDirection.Z);
			} else if (mode == Mode.RMOVE) {
				return RandomMoveThought();
			}
		}
		//end of 3rd update
		for (int i = 0; i < planner.getGoals().size(); i++) {
		}
		if (this.planner.getGoals().isEmpty()){
			return RandomMoveThought();
		}

		this.planner.generatePlan();

		if (!planner.hasPlan()) {
			if (this.mode == Mode.FIND_FUEL_STATION) {
				Int2D newGoal = generateRandomNearCell(planner.getGoals().get(0));
				planner.getGoals().set(0, newGoal);
				planner.generatePlan();
			} else {
				return new TWThought(TWAction.MOVE, TWDirection.Z);
			}
		}
		if (!planner.hasPlan()) {
			return RandomMoveThought();
		}

		TWDirection dir = this.planner.execute();
		return new TWThought(TWAction.MOVE, dir);
	}

//End of update

private Int2D generateRandomNearCell(Int2D goalPos) {
	  ArrayList<Int2D> dirs = new ArrayList<Int2D>();
	  int x = goalPos.getX();
	  int y = goalPos.getY();

	  if ((y-1) >= 0
			  && !this.memory.isCellBlocked(x, y-1)) {
		  dirs.add(new Int2D(x, y-1));
	  }
	  if ((y+1) < this.getEnvironment().getyDimension()
			  && !this.memory.isCellBlocked(x, y+1)) {
		  dirs.add(new Int2D(x, y+1));
	  }
	  if ((x+1) < this.getEnvironment().getxDimension()
			  && !this.memory.isCellBlocked(x+1, y)) {
		  dirs.add(new Int2D(x+1, y));
	  }
	  if ((x-1) >= 0
			  && !this.memory.isCellBlocked(x-1, y)) {
		  dirs.add(new Int2D(x-1, y));
	  }

	  if (dirs.size() > 0) {
		   int random_num = this.getEnvironment().random.nextInt(dirs.size());
		   return dirs.get(random_num);
	  }
	  else {
		  System.out.println("Nowhere to go!");
		  return null;
	  }
	}

private Int2D getPositionAdd(Int2D base, Int2D position) {
		return new Int2D (base.x + position.x, base.y + position.y) ;
	}

public void addGoalsForFuelStation() {
    Int2D[] basePos = {new Int2D(0, 0),
            new Int2D(Parameters.xDimension/2, 0),
            new Int2D(0, Parameters.yDimension/2),
            new Int2D(Parameters.xDimension/2, Parameters.yDimension/2),
            new Int2D(Parameters.xDimension/4, Parameters.yDimension/4)};

    Int2D base = basePos[this.index];
    Int2D position = new Int2D (Parameters.defaultSensorRange, Parameters.defaultSensorRange);
    int depth = Parameters.defaultSensorRange;

    while(depth <= Parameters.xDimension/2) {
        int posX = position.x;
        int posY = position.y;
        planner.getGoals().add(getPositionAdd(base, position));

        posX = Parameters.xDimension/2 - Parameters.defaultSensorRange-1;
        position = new Int2D (posX, position.y);
        planner.getGoals().add(getPositionAdd(base, position));

        posY += Parameters.defaultSensorRange * 2+1;
        depth = depth + Parameters.defaultSensorRange * 2+1;
        if (depth > Parameters.xDimension/2) {
            break;
        }
        position = new Int2D (position.x, posY);
        planner.getGoals().add(getPositionAdd(base, position));

        posX = Parameters.defaultSensorRange;
        position = new Int2D (posX, position.y);
        planner.getGoals().add(getPositionAdd(base, position));
        depth = depth + (Parameters.defaultSensorRange * 2+1);

        posY += Parameters.defaultSensorRange * 2+1;
        position = new Int2D (position.x, posY);
    }
}


	  private ArrayList<TWEntity> detectObjectNoCollision(PriorityQueue<TWEntity> neighborObjects, List<TWAgent> neighbouringAgents) {
		ArrayList<TWEntity> tiles = new ArrayList<TWEntity>();
		while(!neighborObjects.isEmpty()) {
			TWEntity tile = neighborObjects.poll();
			for (int i = 0; i < neighbouringAgents.size(); i++) {
				tiles.add(tile);
			}
		}
		if (!tiles.isEmpty()) return tiles;
		else return null;
	}


	@Override
	protected void act(TWThought thought) {
		Int2D curGoal = planner.getCurrentGoal();

		try {
			switch (thought.getAction()) {
			case MOVE:
				move(thought.getDirection());
				break;
			case PICKUP:
				TWTile tile = (TWTile) memory.getMemoryGrid().get(this.x, this.y);
				pickUpTile(tile);
				planner.getGoals().clear();
				break;
			case PUTDOWN:
				TWHole hole = (TWHole) memory.getMemoryGrid().get(this.x, this.y);
				putTileInHole(hole);
				planner.getGoals().clear();
				break;
			case REFUEL:
				refuel();
				planner.getGoals().clear();
				break;
			}

        } catch (CellBlockedException ex) {
    		System.out.println("Size of goal: "+this.planner.getGoals().size());
    		System.out.println("N: " + this.memory.isCellBlocked(x, y-1));
    		System.out.println("S: " + this.memory.isCellBlocked(x, y+1));
    		System.out.println("E: " + this.memory.isCellBlocked(x+1, y));
    		System.out.println("W: " + this.memory.isCellBlocked(x-1, y));
			System.out.println("Cell is blocked. Current Position: " + Integer.toString(this.x) + ", " + Integer.toString(this.y));
        }
		System.out.println("Step " + this.getEnvironment().schedule.getSteps());
		System.out.println(name + " score: " + this.score);
		System.out.println("Position: " + Integer.toString(this.x) + ", " + Integer.toString(this.y));
		System.out.println("Current Mode: " + this.mode);
		System.out.println("Size of goal: "+this.planner.getGoals().size());

		if (curGoal != null) {
			System.out.println("Goal: " + curGoal.x + ", " + curGoal.y);
		}
		else
			System.out.println("Goal: Nothing");
		System.out.println("Tiles: " + this.carriedTiles.size());
		System.out.println("Fuel Level: " + this.fuelLevel);
		System.out.println("Fuel Station: " + this.memory.getFuelStation());
		System.out.println();

	}
	private TWThought RandomMoveThought() {
	  ArrayList<TWDirection> dirs = new ArrayList<TWDirection>();
	  int x = this.getX();
	  int y = this.getY();

	  if ((y-1) >= 0
			  && !this.memory.isCellBlocked(x, y-1)) {
		  dirs.add(TWDirection.N);
	  }
	  if ((y+1) < this.getEnvironment().getyDimension()
			  && !this.memory.isCellBlocked(x, y+1)) {
		  dirs.add(TWDirection.S);
	  }
	  if ((x+1) < this.getEnvironment().getxDimension()
			  && !this.memory.isCellBlocked(x+1, y)) {
		  dirs.add(TWDirection.E);
	  }
	  if ((x-1) >= 0
			  && !this.memory.isCellBlocked(x-1, y)) {
		  dirs.add(TWDirection.W);
	  }

	  if (dirs.size() > 0) {
	   int random_num = this.getEnvironment().random.nextInt(dirs.size());
	   return new TWThought(TWAction.MOVE, dirs.get(random_num));
	  }
	  else {
	   System.out.println("No where to go!");
	   return new TWThought(TWAction.MOVE, TWDirection.Z);
	  }
    }

	private TWDirection getRandomDirection(int X, int Y){

	    TWDirection randomDir = TWDirection.values()[this.getEnvironment().random.nextInt(5)];

	    if(this.getX()>=this.getEnvironment().getxDimension() ){
	        randomDir = TWDirection.W;
	    }else if(this.getX()<=1 ){
	        randomDir = TWDirection.E;
	    }else if(this.getY()<=1 ){
	        randomDir = TWDirection.S;
	    }else if(this.getY()>=this.getEnvironment().getxDimension() ){
	        randomDir = TWDirection.N;
	    }

	   return randomDir;

	}

	@Override
	public TWAgentWorkingMemory getMemory() {
        return this.memory;
    }
	@Override
	public String getName() {
		return name;
	}



}
