package tileworld.agent;

import sim.util.Int2D;
import tileworld.Parameters;

public enum BoardQuarter {
    NW,
    NE,
    SW,
    SE,
    WORKING_AGENT;

    public Int2D regionCenter() {
        int midX = Parameters.xDimension / 2;
        int midY = Parameters.yDimension / 2;

        int q1X = midX / 2;
        int q3X = midX + q1X;

        int q1Y = midY / 2;
        int q3Y = midY + q1Y;

        switch (this) {
            case NW:
                return new Int2D(q1X, q1Y);
            case NE:
                return new Int2D(q3X, q1Y);
            case SW:
                  return new Int2D(q1X, q3Y);
            case SE:
                return new Int2D(q3X, q3Y);
            case WORKING_AGENT:
                return new Int2D(midX, midY);
        }
        throw new IllegalStateException();
    }


}
