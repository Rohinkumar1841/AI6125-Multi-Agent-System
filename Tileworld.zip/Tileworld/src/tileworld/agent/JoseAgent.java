package tileworld.agent;

import sim.util.Int2D;
import tileworld.Parameters;
import tileworld.environment.TWDirection;
import tileworld.environment.TWEnvironment;

import java.util.*;

public class JoseAgent extends MyAgent {
    public JoseAgent(int index, String name, int xpos, int ypos, TWEnvironment env, double fuelLevel) {
        super(index, name, xpos, ypos, env, fuelLevel);
    }

    private Int2D nextPoint(Int2D point, TWDirection dir, int amt) {
        return new Int2D(point.x + dir.dx * amt, point.y + dir.dy * amt);
    }
    
    @Override
    public void addGoalsForFuelStation() {
        if (this.quarter == BoardQuarter.WORKING_AGENT) {
            this.mode = Mode.COLLECT;
            this.think();
            return;
        }
        this.planner.voidGoals();
        Queue<Int2D> goals = new LinkedList<>();
        // Start from the corner instead of the center
        goals.add(new Int2D(0, 0));

        int quarterWidth = Parameters.xDimension / 2;
        int quarterHeight = Parameters.yDimension / 2;

        TWDirection[] directions = TWDirection.values();
        Set<Int2D> visited = new HashSet<>();

        while (!goals.isEmpty()) {
            Int2D current = goals.poll();
            for (TWDirection dir : directions) {
                Int2D next = nextPoint(current, dir, Parameters.defaultSensorRange);
                if (next.x >= 0 && next.x < quarterWidth && next.y >= 0 && next.y < quarterHeight && !visited.contains(next)) {
                    goals.add(next);
                    visited.add(next);
                }
            }
         
        }
    }
}
