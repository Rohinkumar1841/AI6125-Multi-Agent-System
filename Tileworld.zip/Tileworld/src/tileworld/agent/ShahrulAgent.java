package tileworld.agent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.concurrent.atomic.AtomicReference;

import sim.util.Int2D;
import tileworld.environment.TWEnvironment;
import tileworld.Parameters;


public class ShahrulAgent extends MyAgent {
    public ShahrulAgent(int index, String name, int xpos, int ypos, TWEnvironment env, double fuelLevel) {
        super(index, name, xpos, ypos, env, fuelLevel);
    }

    @Override
    public void addGoalsForFuelStation() {
        if (this.quarter == BoardQuarter.WORKING_AGENT) {
            this.mode = Mode.COLLECT;
            this.think();
            return;
        }
        this.planner.voidGoals();

        ArrayList<Int2D> goals = this.planner.getGoals();

        ArrayList<Int2D> checkpoints = getFuelStationSearchCheckpoints(this.quarter);
        ArrayList<Int2D> sorted_checkpoints = sortCheckpoints(checkpoints, new Int2D(this.getX(), this.getY()), this.quarter);

        for (Int2D checkpoint : sorted_checkpoints) {
            goals.add(checkpoint);
        }
    }

    private ArrayList<Int2D> getFuelStationSearchCheckpoints(BoardQuarter quarter) {

        // Get checkpoint steps
        int midX = Parameters.xDimension / 2;
        int midY = Parameters.yDimension / 2;

        int x_increments = Parameters.defaultSensorRange;
        int y_increments = Parameters.defaultSensorRange;

        // Get checkpoint locations
        ArrayList<Int2D> checkpoints = new ArrayList<Int2D>();
        switch (quarter) {
            case NW:
                for (int x = 0 + x_increments; x < midX; x = x + x_increments) {
                    for (int y = 0 + y_increments; y < midY; y = y + y_increments) {
                        checkpoints.add(new Int2D(x, y));
                    }
                }
                return checkpoints;
            case NE:
                for (int x = midX + x_increments; x < Parameters.xDimension; x = x + x_increments) {
                    for (int y = 0 + y_increments; y < midY; y = y + y_increments) {
                        checkpoints.add(new Int2D(x, y));
                    }
                }
                return checkpoints;
            case SW:
                for (int x = 0 + x_increments; x < midX; x = x + x_increments) {
                    for (int y = midY + y_increments; y < Parameters.yDimension; y = y + y_increments) {
                        checkpoints.add(new Int2D(x, y));
                    }
                }
                return checkpoints;
            case SE:
                for (int x = midX + x_increments; x < Parameters.xDimension; x = x + x_increments) {
                    for (int y = midY + y_increments; y < Parameters.yDimension; y = y + y_increments) {
                        checkpoints.add(new Int2D(x, y));
                    }
                }
                return checkpoints;
        }
        throw new IllegalStateException();
    }

    private ArrayList<Int2D> sortCheckpoints(ArrayList<Int2D> checkpoints, Int2D agent_pos, BoardQuarter quarter) {
        ArrayList<Int2D> sorted_checkpoints = new ArrayList<Int2D>();

        AtomicReference<Int2D> anchor_point = new AtomicReference<>(agent_pos);
        while (checkpoints.size() > 0) {
            Int2D closest_checkpoint = checkpoints
                .stream()
                .min(Comparator.comparingDouble((Int2D o) -> o.distance(anchor_point.get())))
                .orElseThrow(null);
            sorted_checkpoints.add(closest_checkpoint);
            checkpoints.remove(closest_checkpoint);

            anchor_point.set(closest_checkpoint);
        }

        return sorted_checkpoints;
    }
}
