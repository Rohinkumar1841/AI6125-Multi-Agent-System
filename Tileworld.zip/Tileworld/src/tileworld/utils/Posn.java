package tileworld.utils;

/**
 * A coordinate function: both stores the coordinates at once, and also makes it nullable.
 * I would write this in
 */
public class Posn {
    public final int x;
    public final int y;

    public Posn(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean equals(Object other) {
        return (other instanceof Posn)
                && this.x == ((Posn) other).x
                && this.y == ((Posn) other).y;
    }
}
