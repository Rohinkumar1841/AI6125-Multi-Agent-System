/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package tileworld.exceptions;

/**
 * TWContextBuilder
 *
 * @author michaellees
 * Created: Apr 26, 2010
 *
 * Copyright michaellees Expression year is undefined on line 16, column 24 in Templates/Classes/Class.java.
 *
 *
 * Description:
 *
 */
public class CellBlockedException extends Exception{

    public CellBlockedException() {
    }

}
