/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package tileworld.exceptions;

/**
 * InsufficientFuelException
 *
 * @author michaellees
 * Created: Apr 21, 2010
 *
 * Copyright michaellees 2010
 *
 *
 * Description:
 *
 */
public class InsufficientFuelException extends RuntimeException{

    public InsufficientFuelException() {
        super();
    }

    public InsufficientFuelException(String string) {
        super(string);
    }

}
